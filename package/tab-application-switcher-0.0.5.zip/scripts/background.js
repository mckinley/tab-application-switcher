(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var _events = require('events');

var _events2 = _interopRequireDefault(_events);

var _tabs = require('./lib/background/tabs');

var _tabs2 = _interopRequireDefault(_tabs);

var _omnibox = require('./lib/background/omnibox');

var _omnibox2 = _interopRequireDefault(_omnibox);

var _connection = require('./lib/background/connection');

var _connection2 = _interopRequireDefault(_connection);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var eventEmitter = new _events2.default();
new _tabs2.default(eventEmitter);
new _omnibox2.default(eventEmitter);
new _connection2.default();

},{"./lib/background/connection":2,"./lib/background/omnibox":3,"./lib/background/tabs":4,"events":5}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Connection = function () {
  function Connection() {
    _classCallCheck(this, Connection);

    // Required for onDisconnect in content scripts to execute only when reload occurs.
    // Without a listener, onDesconnect is called immediatly.
    chrome.runtime.onConnect.addListener(function () {});

    this.executeContentScripts();
  }

  _createClass(Connection, [{
    key: 'executeContentScripts',
    value: function executeContentScripts() {
      var manifest = chrome.app.getDetails();
      var scripts = manifest.content_scripts[0].js;
      chrome.tabs.query({}, function (tabs) {
        tabs.forEach(function (tab) {
          if (!tab.url.match('chrome.google.com/webstore') && !tab.url.match('chrome://')) {
            scripts.forEach(function (script) {
              chrome.tabs.executeScript(tab.id, { file: script, matchAboutBlank: true }, function (result) {
                var e = chrome.runtime.lastError;
                if (e !== undefined) {
                  console.log('Error executing content script in tab: ', tab, 'result: ', result, 'chrome.runtime.lastError: ', e);
                }
              });
            });
          }
        });
      });
    }
  }]);

  return Connection;
}();

exports.default = Connection;

},{}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Omnibox = function () {
  function Omnibox(eventEmitter) {
    var _this = this;

    _classCallCheck(this, Omnibox);

    this.eventEmitter = eventEmitter;
    this.tabs = [];

    chrome.omnibox.onInputStarted.addListener(function () {
      _this.getTabs();
    });

    chrome.omnibox.onInputChanged.addListener(function (text, suggest) {
      _this.suggest(text, suggest);
    });

    chrome.omnibox.onInputEntered.addListener(function (text, _disposition) {
      var tab = _this.findTab(text);
      if (!tab) {
        tab = _this.matchedTabs(text)[0];
      }
      if (tab) {
        _this.eventEmitter.emit('omnibox:select-tab', tab);
      }
    });
  }

  _createClass(Omnibox, [{
    key: 'getTabs',
    value: function getTabs() {
      var _this2 = this;

      chrome.runtime.sendMessage({ tabs: true }, function (response) {
        _this2.tabs = response.tabs;
      });
    }
  }, {
    key: 'suggest',
    value: function suggest(text, _suggest) {
      var _this3 = this;

      var suggestions = [];
      var matchedTabs = this.matchedTabs(text);
      matchedTabs.forEach(function (tab) {
        suggestions.push({ content: tab.url, description: 'tab: <match>' + _this3.encodeXml(tab.title) + '</match>' });
      });

      if (suggestions.length > 0) {
        chrome.omnibox.setDefaultSuggestion({ description: suggestions[0].description });
        suggestions.shift();
      }

      if (suggestions.length > 0) {
        _suggest(suggestions);
      }
    }
  }, {
    key: 'match',
    value: function match(text, tab) {
      return tab.title.match(new RegExp(text)) || tab.url.match(new RegExp(text));
    }
  }, {
    key: 'matchedTabs',
    value: function matchedTabs(text) {
      var _this4 = this;

      var matchedTabs = [];
      this.tabs.forEach(function (tab) {
        if (_this4.match(text, tab)) {
          matchedTabs.push(tab);
        }
      });
      return matchedTabs;
    }
  }, {
    key: 'findTab',
    value: function findTab(url) {
      return this.tabs.find(function (tab) {
        return tab && tab.url === url;
      });
    }
  }, {
    key: 'encodeXml',
    value: function encodeXml(s) {
      var holder = document.createElement('div');
      holder.textContent = s;
      return holder.innerHTML;
    }
  }]);

  return Omnibox;
}();

exports.default = Omnibox;

},{}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Tabs = function () {
  function Tabs(eventEmitter) {
    var _this = this;

    _classCallCheck(this, Tabs);

    this.eventEmitter = eventEmitter;
    this.tabs = [];

    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
      if (request.tabs) {
        sendResponse({ tabs: _this.tabs });
      } else if (request.selectTab) {
        _this.selectTab(request.selectTab);
      }
    });

    this.eventEmitter.on('omnibox:select-tab', function (tab) {
      _this.selectTab(tab);
    });

    chrome.tabs.onCreated.addListener(function (tab) {
      if (tab.active) {
        _this.tabs.unshift(tab);
      } else {
        _this.tabs.push(tab);
      }
    });

    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
      _this.tabs[_this.tabs.indexOf(_this.findTab(tabId))] = tab;
    });

    chrome.tabs.onReplaced.addListener(function (addedTabId, removedTabId) {
      _this.removeTab(removedTabId);
    });

    chrome.tabs.onRemoved.addListener(function (id) {
      _this.removeTab(id);
    });

    chrome.tabs.onActivated.addListener(function (info) {
      _this.unshiftTab(_this.findTab(info.tabId));
    });

    chrome.windows.onFocusChanged.addListener(function () {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        if (tabs[0]) {
          _this.unshiftTab(_this.findTab(tabs[0].id));
        }
      });
    });

    this.getTabs();
  }

  _createClass(Tabs, [{
    key: 'getTabs',
    value: function getTabs() {
      var _this2 = this;

      chrome.windows.getAll({ populate: true }, function (windows) {
        var focused = void 0;
        windows.forEach(function (w) {

          function toDataURL(url, callback) {
            var xhr = new XMLHttpRequest();
            xhr.onload = function () {
              var reader = new FileReader();
              reader.onloadend = function () {
                callback(reader.result);
              };
              reader.readAsDataURL(xhr.response);
            };
            xhr.open('GET', url);
            xhr.responseType = 'blob';
            xhr.send();
          }

          w.tabs.map(function (t) {
            toDataURL('chrome://favicon/size/16@1x/' + t.url, function (dataUrl) {
              console.log(dataUrl);
              t.favIconDataUrl = dataUrl;
            });
          });

          if (w.focused) {
            focused = w;
          } else {
            _this2.tabs = w.tabs.concat(_this2.tabs);
          }
        });

        if (focused) {
          _this2.tabs = focused.tabs.concat(_this2.tabs);
          _this2.unshiftTab(focused.tabs.find(function (tab) {
            return tab.active;
          }));
        }
      });
    }
  }, {
    key: 'selectTab',
    value: function selectTab(tab) {
      chrome.windows.update(tab.windowId, { focused: true });
      chrome.tabs.update(tab.id, { selected: true });
    }
  }, {
    key: 'unshiftTab',
    value: function unshiftTab(tab) {
      var index = this.tabs.indexOf(tab);
      if (index === -1) {
        this.tabs.unshift(tab);
      } else {
        this.tabs.unshift(this.tabs.splice(index, 1)[0]);
      }
    }
  }, {
    key: 'removeTab',
    value: function removeTab(id) {
      this.tabs.splice(this.tabs.indexOf(this.findTab(id)), 1);
    }
  }, {
    key: 'findTab',
    value: function findTab(id) {
      return this.tabs.find(function (tab) {
        return tab && tab.id === id;
      });
    }
  }]);

  return Tabs;
}();

exports.default = Tabs;

},{}],5:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

function EventEmitter() {
  this._events = this._events || {};
  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
EventEmitter.defaultMaxListeners = 10;

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function(n) {
  if (!isNumber(n) || n < 0 || isNaN(n))
    throw TypeError('n must be a positive number');
  this._maxListeners = n;
  return this;
};

EventEmitter.prototype.emit = function(type) {
  var er, handler, len, args, i, listeners;

  if (!this._events)
    this._events = {};

  // If there is no 'error' event listener then throw.
  if (type === 'error') {
    if (!this._events.error ||
        (isObject(this._events.error) && !this._events.error.length)) {
      er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      } else {
        // At least give some kind of context to the user
        var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
        err.context = er;
        throw err;
      }
    }
  }

  handler = this._events[type];

  if (isUndefined(handler))
    return false;

  if (isFunction(handler)) {
    switch (arguments.length) {
      // fast cases
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      // slower
      default:
        args = Array.prototype.slice.call(arguments, 1);
        handler.apply(this, args);
    }
  } else if (isObject(handler)) {
    args = Array.prototype.slice.call(arguments, 1);
    listeners = handler.slice();
    len = listeners.length;
    for (i = 0; i < len; i++)
      listeners[i].apply(this, args);
  }

  return true;
};

EventEmitter.prototype.addListener = function(type, listener) {
  var m;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events)
    this._events = {};

  // To avoid recursion in the case that type === "newListener"! Before
  // adding it to the listeners, first emit "newListener".
  if (this._events.newListener)
    this.emit('newListener', type,
              isFunction(listener.listener) ?
              listener.listener : listener);

  if (!this._events[type])
    // Optimize the case of one listener. Don't need the extra array object.
    this._events[type] = listener;
  else if (isObject(this._events[type]))
    // If we've already got an array, just append.
    this._events[type].push(listener);
  else
    // Adding the second element, need to change to array.
    this._events[type] = [this._events[type], listener];

  // Check for listener leak
  if (isObject(this._events[type]) && !this._events[type].warned) {
    if (!isUndefined(this._maxListeners)) {
      m = this._maxListeners;
    } else {
      m = EventEmitter.defaultMaxListeners;
    }

    if (m && m > 0 && this._events[type].length > m) {
      this._events[type].warned = true;
      console.error('(node) warning: possible EventEmitter memory ' +
                    'leak detected. %d listeners added. ' +
                    'Use emitter.setMaxListeners() to increase limit.',
                    this._events[type].length);
      if (typeof console.trace === 'function') {
        // not supported in IE 10
        console.trace();
      }
    }
  }

  return this;
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.once = function(type, listener) {
  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  var fired = false;

  function g() {
    this.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  g.listener = listener;
  this.on(type, g);

  return this;
};

// emits a 'removeListener' event iff the listener was removed
EventEmitter.prototype.removeListener = function(type, listener) {
  var list, position, length, i;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events || !this._events[type])
    return this;

  list = this._events[type];
  length = list.length;
  position = -1;

  if (list === listener ||
      (isFunction(list.listener) && list.listener === listener)) {
    delete this._events[type];
    if (this._events.removeListener)
      this.emit('removeListener', type, listener);

  } else if (isObject(list)) {
    for (i = length; i-- > 0;) {
      if (list[i] === listener ||
          (list[i].listener && list[i].listener === listener)) {
        position = i;
        break;
      }
    }

    if (position < 0)
      return this;

    if (list.length === 1) {
      list.length = 0;
      delete this._events[type];
    } else {
      list.splice(position, 1);
    }

    if (this._events.removeListener)
      this.emit('removeListener', type, listener);
  }

  return this;
};

EventEmitter.prototype.removeAllListeners = function(type) {
  var key, listeners;

  if (!this._events)
    return this;

  // not listening for removeListener, no need to emit
  if (!this._events.removeListener) {
    if (arguments.length === 0)
      this._events = {};
    else if (this._events[type])
      delete this._events[type];
    return this;
  }

  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    for (key in this._events) {
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = {};
    return this;
  }

  listeners = this._events[type];

  if (isFunction(listeners)) {
    this.removeListener(type, listeners);
  } else if (listeners) {
    // LIFO order
    while (listeners.length)
      this.removeListener(type, listeners[listeners.length - 1]);
  }
  delete this._events[type];

  return this;
};

EventEmitter.prototype.listeners = function(type) {
  var ret;
  if (!this._events || !this._events[type])
    ret = [];
  else if (isFunction(this._events[type]))
    ret = [this._events[type]];
  else
    ret = this._events[type].slice();
  return ret;
};

EventEmitter.prototype.listenerCount = function(type) {
  if (this._events) {
    var evlistener = this._events[type];

    if (isFunction(evlistener))
      return 1;
    else if (evlistener)
      return evlistener.length;
  }
  return 0;
};

EventEmitter.listenerCount = function(emitter, type) {
  return emitter.listenerCount(type);
};

function isFunction(arg) {
  return typeof arg === 'function';
}

function isNumber(arg) {
  return typeof arg === 'number';
}

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}

function isUndefined(arg) {
  return arg === void 0;
}

},{}]},{},[1]);
